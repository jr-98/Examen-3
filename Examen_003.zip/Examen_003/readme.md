This is a very basic example of CRUD in Node.js n mySQL.

Installation,Live DEMO, and tutorial here : http://teknosains.com/i/simple-crud-nodejs-mysql

## Installation
*for newbies : Clone or download zip to your machine then hit this :

	npm install

## Configuration (database)
app.js

        host: 'localhost',
        user: 'root',
        password : 'root',
        port : 3306, //port mysql
        database:'nodejs'	


	
You're gonna need to create a DB named 'nodejs' and import customer.sql

## NOTES
This repo still use Express 3, you might want to upgrade yourself or you can Go here (https://github.com/codetrash/rest-crud) for newest Express 
